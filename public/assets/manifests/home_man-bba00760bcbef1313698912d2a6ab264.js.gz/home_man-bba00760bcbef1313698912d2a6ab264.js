(function(){
    angular.module('home',[]);
})();

// module
//*******

;
